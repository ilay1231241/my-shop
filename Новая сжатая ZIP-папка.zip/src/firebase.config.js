// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCgOhcH4A6TNU5EYD2aZjON40PQQcxsn5I",
  authDomain: "blagoapp-baf76.firebaseapp.com",
  projectId: "blagoapp-baf76",
  storageBucket: "blagoapp-baf76.appspot.com",
  messagingSenderId: "98401416759",
  appId: "1:98401416759:web:db63576909453f506bb1b2",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
