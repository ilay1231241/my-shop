import axios from "axios";

export async function productsData() {
  const products = await axios.get(
    "https://api.jsonstorage.net/v1/json/f8536709-3acd-4387-82b0-1b74a87de219/c3c1c592-6547-4285-a80a-a4d8cf1640cc"
  );
  return products;
}
